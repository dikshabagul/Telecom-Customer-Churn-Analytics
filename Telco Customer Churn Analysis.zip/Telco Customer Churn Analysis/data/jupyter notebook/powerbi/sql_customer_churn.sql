CREATE DATABASE IF NOT EXISTS customer_churn;
USE customer_churn;

CREATE TABLE telco_churn (
    customerID VARCHAR(20) PRIMARY KEY,
    gender VARCHAR(10),
    SeniorCitizen TINYINT,
    Partner VARCHAR(5),
    Dependents VARCHAR(5),
    tenure INT,
    PhoneService VARCHAR(5),
    MultipleLines VARCHAR(20),
    InternetService VARCHAR(20),
    OnlineSecurity VARCHAR(5),
    OnlineBackup VARCHAR(5),
    DeviceProtection VARCHAR(5),
    TechSupport VARCHAR(5),
    StreamingTV VARCHAR(5),
    StreamingMovies VARCHAR(5),
    Contract VARCHAR(20),
    PaperlessBilling VARCHAR(5),
    PaymentMethod VARCHAR(50),
    MonthlyCharges DECIMAL(10,2),
    TotalCharges DECIMAL(10,2),
    Churn TINYINT
);


-- ===============================================
-- Churn Data Exploration
-- ===============================================



-- 1️ Total Customers
SELECT COUNT(*) AS total_customers
FROM telco_churn;

-- 2️ Total Churned Customers
SELECT COUNT(*) AS churned_customers
FROM telco_churn
WHERE Churn = 1;

-- 3️ Churn Rate (%)
SELECT ROUND(SUM(Churn)/COUNT(*)*100,2) AS churn_rate_percent
FROM telco_churn;

-- 4️ Churn by Gender
SELECT gender,
       COUNT(*) AS total_customers,
       SUM(Churn) AS churned_customers,
       ROUND(SUM(Churn)/COUNT(*)*100,2) AS churn_rate_percent
FROM telco_churn
GROUP BY gender;

-- 5️ Churn by Contract Type
SELECT Contract,
       COUNT(*) AS total_customers,
       SUM(Churn) AS churned_customers,
       ROUND(SUM(Churn)/COUNT(*)*100,2) AS churn_rate_percent
FROM telco_churn
GROUP BY Contract
ORDER BY churn_rate_percent DESC;

-- 6️ Average Monthly and Total Charges by Churn
SELECT Churn,
       ROUND(AVG(MonthlyCharges),2) AS avg_monthly_charges,
       ROUND(AVG(TotalCharges),2) AS avg_total_charges
FROM telco_churn
GROUP BY Churn;

-- 7️ Churn by Internet Service Type
SELECT InternetService,
       COUNT(*) AS total_customers,
       SUM(Churn) AS churned_customers,
       ROUND(SUM(Churn)/COUNT(*)*100,2) AS churn_rate_percent
FROM telco_churn
GROUP BY InternetService;

-- 8 Churn by Payment Method
SELECT PaymentMethod,
       COUNT(*) AS total_customers,
       SUM(Churn) AS churned_customers,
       ROUND(SUM(Churn)/COUNT(*)*100,2) AS churn_rate_percent
FROM telco_churn
GROUP BY PaymentMethod;


-- ===============================================
-- Retention Insights
-- ===============================================


-- 1️ Average Tenure by Churn
SELECT Churn,
       ROUND(AVG(tenure),2) AS avg_tenure
FROM telco_churn
GROUP BY Churn;

-- 2️ High-Risk Customers: Month-to-Month + High MonthlyCharges
SELECT customerID, Contract, MonthlyCharges, TotalCharges, Churn
FROM telco_churn
WHERE Contract = 'Month-to-month'
  AND MonthlyCharges > (SELECT AVG(MonthlyCharges) FROM telco_churn)
  AND Churn = 1
ORDER BY MonthlyCharges DESC;

-- 3️ Churn by Partner & Dependents
SELECT Partner, Dependents,
       COUNT(*) AS total_customers,
       SUM(Churn) AS churned_customers,
       ROUND(SUM(Churn)/COUNT(*)*100,2) AS churn_rate_percent
FROM telco_churn
GROUP BY Partner, Dependents
ORDER BY churn_rate_percent DESC;

-- 4️ Churn by Tech Support Subscription
SELECT TechSupport,
       COUNT(*) AS total_customers,
       SUM(Churn) AS churned_customers,
       ROUND(SUM(Churn)/COUNT(*)*100,2) AS churn_rate_percent
FROM telco_churn
GROUP BY TechSupport;

-- 5️ Customers with No Online Security + Churn
SELECT customerID, InternetService, OnlineSecurity, Churn
FROM telco_churn
WHERE OnlineSecurity = 'No'
  AND Churn = 1;


